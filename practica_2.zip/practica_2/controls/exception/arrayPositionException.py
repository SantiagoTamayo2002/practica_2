class ArrayPositionException(Exception):
    pass