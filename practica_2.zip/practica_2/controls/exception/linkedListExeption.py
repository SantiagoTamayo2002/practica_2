class LinkedEmptyException(Exception):
    pass
class ArrayPositionException(Exception):
    pass